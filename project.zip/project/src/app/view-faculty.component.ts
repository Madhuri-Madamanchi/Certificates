import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';

@Component({
  selector: 'app-view-faculty',
  templateUrl: './view-faculty.component.html',
  styleUrls: ['./view-faculty.component.css']
})
export class ViewFacultyComponent implements OnInit {

  faculty:any=[];
  courses:any=[];
  constructor(private service:ImsService) { }

  ngOnInit(): void {
    this.service.viewFaculty().subscribe((data:any)=>{
      this.faculty=data;
      console.log(this.faculty)
    })
  }

  delete(name){

    this.service.deleteFaculty(name).subscribe((data)=>{
      if(data==1){
        alert("deleted successfully")
        window.location.reload();
      }
    })
  }
}
