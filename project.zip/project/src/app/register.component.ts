import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';
import { element } from 'protractor';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  model:any={};
  courses:any=[];
  selectedCoures:any=[];

  constructor(private service:ImsService) { }
  onSubmit(){
    this.service.register(this.model,this.selectedCoures).subscribe((data:any)=>{
      if(data==1)
      alert("registered successfully")
      else
      alert("Register once again")
    })
  }
  submit1(value:any){
    this.selectedCoures.push(value);
  }

  ngOnInit() {
    this.service.getAllCourses().subscribe((data:any)=>{
      this.courses=data;
    })
  }

}
