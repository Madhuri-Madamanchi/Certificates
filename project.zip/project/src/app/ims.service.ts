import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { from, Observable } from 'rxjs';
import { UrlResolver } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class ImsService {
  selectedCourse: any;
  selectedFaculty: any;
  usermobile: any;
  userpass: any;
  fMail: any;

  constructor(private http:HttpClient) { }
  loginFaculty(mobieNo:any,password:any){
 return this.http.get("http://localhost:9010/login/"+mobieNo+"/"+password);
  }
  loginUser(mobieNo:any,password:any){
    console.log(mobieNo+password)
    return this.http.get("http://localhost:9010/loginUser/"+mobieNo+"/"+password)

  }
  getAllCourses(){
    return this.http.get("http://localhost:9010/getAllCourses");
  }
  register(user:any,courses:any){
    let input={
      "mobileNo":user.mobile,
      "name":user.name,
      "mailId":user.email,
      "pasword":user.password,
      "courses":courses
      
    }
    return this.http.post("http://localhost:9010/addFaculty",input)
  }
  addCourses(courses){
    console.log(courses);
    let input={
      "courseName":courses.courseName,
      "duration":courses.courseDuration,
      "price":courses.coursePrice
    }
    return this.http.post("http://localhost:9010/addCourses",input)
  }
  deleteCourse(courseName:any){
   return  this.http.delete("http://localhost:9010/deleteCourse/"+courseName)
  }
  viewFaculty(){
    return this.http.get("http://localhost:9010/getAllFaculty");
  }
  deleteFaculty(name){
    return this.http.delete("http://localhost:9010/deleteFaculty/"+name)
  }
  getAllStudents(){
    return this.http.get("http://localhost:9010/getAllStudents");
  }
  studentRegister(student){
    let input={
      "mobileNo":student.mobile,
      "name":student.name,
      "mailId":student.email,
      "password":student.password
    }
    return this.http.post("http://localhost:9010/addStudent",input);
  }
  getFaculty(courseName){
    return this.http.get("http://localhost:9010/getAllFaculty/"+courseName);
  }
  bookFaculty(){
    console.log(this.usermobile+this.selectedFaculty+this.selectedCourse)
    return this.http.get("http://localhost:9010/bookFaculty/"+this.usermobile+"/"+this.selectedFaculty+"/"+this.selectedCourse);
  }
  getbookedCourse(){
    return this.http.get("http://localhost:9010/getCourses/"+this.usermobile);
  }
  getStudents(){
    return this.http.get("http://localhost:9010/getStudents/"+this.fMail);
  }
}
