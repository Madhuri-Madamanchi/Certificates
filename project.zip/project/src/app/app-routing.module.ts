import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';

import { ViewCourseComponent } from './view-course.component';
import { AddFacultyComponent } from './add-faculty.component';
import { ViewFacultyComponent } from './view-faculty.component';
import { ViewStudentComponent } from './view-student.component';
import { AddCourseComponent } from './add-course.component';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { StudCourseComponent } from './stud-course.component';
import { FacultyComponent } from './faculty.component';


const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'addCourse',component:AddCourseComponent},
  {path:'viewCourse',component:ViewCourseComponent},
  {path:'addFaculty',component:AddFacultyComponent},
  {path:'viewFaculty',component:ViewFacultyComponent},
  {path:'viewStudent',component:ViewStudentComponent},
  {path:'studregister',component:StudentRegisterComponent},
  {path:'studcourse',component:StudCourseComponent},
  {path:'faculty',component:FacultyComponent},
  {path:'',redirectTo:"/studregister",pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
