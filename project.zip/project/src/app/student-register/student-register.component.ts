import { Component, OnInit } from '@angular/core';
import { ImsService } from '../ims.service';

@Component({
  selector: 'app-student-register',
  templateUrl: './student-register.component.html',
  styleUrls: ['./student-register.component.css']
})
export class StudentRegisterComponent implements OnInit {

  model:any={};
  constructor(private service:ImsService) { }

  ngOnInit(): void {
  }

  onSubmit(){

    console.log(this.model)
    this.service.studentRegister(this.model).subscribe((data)=>{
      if(data==1)
      alert("Registered successfully")
      else
      alert("Already registered")
    })
  }
}
