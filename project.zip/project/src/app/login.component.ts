import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ImsService } from './ims.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  data:any;
  mobile:any;
  pwd:any;
  data1:any;
  password:any;
role:any;
  constructor(private router:Router,private service:ImsService) { }
  onSubmit(userForm){
    if(userForm.role=="admin" || userForm.role=="Faculty")
    {
      this.service.loginFaculty(userForm.mobile,userForm.password).subscribe((data:any)=>{
        console.log(data);
        if(data==1)
        this.router.navigate(['./register'])
        else if(data==2){
          this.service.fMail=userForm.mobile;
        this.router.navigate(['faculty'])
        }
        else
        alert("you are not authorized person")
      })
    }
   else
    {
      this.service.loginUser(userForm.mobile,userForm.password).subscribe((data)=>{
        if(data==1){
          this.service.usermobile=userForm.mobile;
          this.service.userpass=userForm.password;
          
        this.router.navigate(["./studcourse"]);
        }
        else if(data==2)
        alert("enter correct password")
        else
        alert("you are not registered yet!!")
      })
    }
    
    

  }
  

 

  ngOnInit(): void {
  }

}
