import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';

@Component({
  selector: 'app-view-student',
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.css']
})
export class ViewStudentComponent implements OnInit {

  students:any=[];
  constructor(private service:ImsService) { }

  ngOnInit(): void {
    this.service.getAllStudents().subscribe((data)=>{
      this.students=data;
    })
  }

}
