import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {
course:any={}
  constructor(private service:ImsService,private router:Router) { }

  ngOnInit(): void {
  }

  submit(){
    this.service.addCourses(this.course).subscribe((data)=>{
      if(data==1){
      alert("Added successfully");
        this.router.navigate(['./viewCourse'])
      }

      else
      alert("Course already added");
    })
  }
}
