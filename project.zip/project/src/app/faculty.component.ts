import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';

@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})
export class FacultyComponent implements OnInit {

  constructor(private service:ImsService) { }
  students:any;
  ngOnInit(): void {
    this.service.getStudents().subscribe((data)=>{
      this.students=data;
    })
  }

}
