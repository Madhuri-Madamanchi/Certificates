import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login.component';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './register.component';
import { ViewCourseComponent } from './view-course.component';

import { ViewFacultyComponent } from './view-faculty.component';
import { ViewStudentComponent } from './view-student.component';
import { AddCourseComponent } from './add-course.component';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { StudCourseComponent } from './stud-course.component';
import { FacultyComponent } from './faculty.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ViewCourseComponent,
    
    ViewFacultyComponent,
    ViewStudentComponent,
    AddCourseComponent,
    StudentRegisterComponent,
    StudCourseComponent,
    FacultyComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
