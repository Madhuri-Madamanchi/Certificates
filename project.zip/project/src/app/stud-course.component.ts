import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-stud-course',
  templateUrl: './stud-course.component.html',
  styleUrls: ['./stud-course.component.css']
})
export class StudCourseComponent implements OnInit {

  course:any=[];
  course1:any;
  faculty:any;
  faculty1:any=[];
  registered:any;
  bookedCourses:any=[];
  constructor(private service:ImsService,private router:Router) { }

  ngOnInit(): void {
    this.service.getAllCourses().subscribe((data)=>{
      this.course=data;
      this.course1=true;
    })

  }
  viewFaculty(course){
    this.faculty=true;
    this.course1=false;
    
    this.service.selectedCourse=course;
    this.service.getFaculty(course).subscribe((data)=>{
      this.faculty1=data;
    })

  }
  bookFaculty(faculty){
    this.service.selectedFaculty=faculty;
    this.service.bookFaculty().subscribe((data)=>{
      if(data==1)
      alert("booked sucessfully")
    })
  }
  view(){
    this.faculty=false;
    this.course1=false;
    this.registered=true;
    this.service.getbookedCourse().subscribe((data)=>{
      this.bookedCourses=data;
    })

  }
  back(){
    this.router.navigate(['./studcourse']);
  }
}
