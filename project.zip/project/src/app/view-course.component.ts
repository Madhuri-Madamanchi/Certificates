import { Component, OnInit } from '@angular/core';
import { ImsService } from './ims.service';

@Component({
  selector: 'app-view-course',
  templateUrl: './view-course.component.html',
  styleUrls: ['./view-course.component.css']
})
export class ViewCourseComponent implements OnInit {

  course:any=[];
  constructor(private service:ImsService) { }

  ngOnInit(): void {
    this.service.getAllCourses().subscribe((data)=>{
      this.course=data;
    })
  }

  delete(courseName){
    console.log(courseName)
    this.service.deleteCourse(courseName).subscribe((data:any)=>{
      if(data==1){
      alert("Deleted Successully")
      window.location.reload();
      }
    })
  }
}
