 package com.example.Ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Ims.dao.ImsDao;
import com.example.Ims.dto.Course;
import com.example.Ims.dto.Faculty;
import com.example.Ims.dto.Student;

@Service
public class ImsServiceImp implements ImsService{
	@Autowired
	ImsDao dao;
	

	@Override
	public Integer addFaculty(Faculty faculty) {
		// TODO Auto-generated method stub
		return dao.addFaculty(faculty);
	}


	@Override
	public Integer addStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.addStudent(student);
	}


	@Override
	public List<Course> getCourses(Long mobileNo) {
		// TODO Auto-generated method stub
		return dao.getCourses(mobileNo);
	}


	@Override
	public List<Faculty> getFaculty(String courseName) {
		// TODO Auto-generated method stub
		return dao.getFaculty(courseName);
	}


	@Override
	public Integer addCourses(Course course) {
		// TODO Auto-generated method stub
		return dao.addCourses(course);
	}


	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return dao.getAllCourses();
	}


	@Override
	public List<Student> getStudents(Long fmobile) {
		// TODO Auto-generated method stub
		return dao.getStudents(fmobile);
	}


	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return dao.getAllStudents();
	}


	@Override
	public Integer loginValidation(Long mobileNo, String password) {
		// TODO Auto-generated method stub
		return dao.loginValidation(mobileNo,password);
	}


	@Override
	public Integer loginValidationUser(Long mobileNo, String password) {
		// TODO Auto-generated method stub
		return dao.loginValidationUser(mobileNo, password);
	}


	@Override
	public Integer deleteCourse(String courseName) {
		// TODO Auto-generated method stub
		return dao.deleteCourse(courseName);
	}


	@Override
	public List<Faculty> getAllFaculty() {
		// TODO Auto-generated method stub
		return dao.getAllFaculty();
	}


	@Override
	public Integer deleteFaculty(String fName) {
		// TODO Auto-generated method stub
		return dao.deleteFaculty(fName);
	}


	@Override
	public Integer bookFaculty(Long umail, Long fmail, String courseName) {
		// TODO Auto-generated method stub
		return dao.getBookedFaculty(umail,fmail,courseName);
	}


	

}
