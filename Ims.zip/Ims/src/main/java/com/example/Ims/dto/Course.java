package com.example.Ims.dto;

public class Course {
	private String courseName;
	private String duration,price;
	public String getCourseName() {
		return courseName;
	}	
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public Course(String courseName, String duration, String price) {
		super();
		this.courseName = courseName;
		this.duration = duration;
		this.price = price;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", duration=" + duration + ", price=" + price + "]";
	}

}

