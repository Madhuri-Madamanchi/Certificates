package com.example.Ims.dao;

import java.util.List;

import com.example.Ims.dto.Course;
import com.example.Ims.dto.Faculty;
import com.example.Ims.dto.Student;

public interface ImsDao {

	Integer addFaculty(Faculty faculty);

	Integer addStudent(Student student);

	List<Course> getCourses(Long mobileNo);

	List<Faculty> getFaculty(String courseName);
	
	List<Faculty> getBookedFaculty(Long mobileNo);

	Integer addCourses(Course course);

	List<Course> getAllCourses();

	List<Student> getStudents(Long fmobile);

	List<Student> getAllStudents();

	Integer loginValidation(Long mobileNo, String password);

	Integer loginValidationUser(Long mobileNo, String password);

	Integer deleteCourse(String courseName);

	List<Faculty> getAllFaculty();

	Integer deleteFaculty(String fName);

	Integer getBookedFaculty(Long umail, Long fmail, String courseName);



}
