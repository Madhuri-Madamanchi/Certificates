package com.example.Ims.service;

import java.util.List;

import com.example.Ims.dto.Course;
import com.example.Ims.dto.Faculty;
import com.example.Ims.dto.Student;

public interface ImsService {

	public Integer addFaculty(Faculty faculty);

	public Integer addStudent(Student student);

	public List<Course> getCourses(Long mobileNo);

	public List<Faculty> getFaculty(String courseName);

	public Integer addCourses(Course course);

	public List<Course> getAllCourses();

	public List<Student> getStudents(Long fmobile);

	public List<Student> getAllStudents();

	public Integer loginValidation(Long mobileNo, String password);

	public Integer loginValidationUser(Long mobileNo, String password);

	public Integer deleteCourse(String courseName);

	public List<Faculty> getAllFaculty();

	public Integer deleteFaculty(String fName);

	public Integer bookFaculty(Long umobile, Long fmobile, String courseName);

	

}
