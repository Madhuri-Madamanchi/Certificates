package com.example.Ims.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Ims.dto.Course;
import com.example.Ims.dto.Faculty;
import com.example.Ims.dto.Student;
import com.example.Ims.service.ImsService;

@RestController
@CrossOrigin("http://localhost:4200")
public class ImsController {
	@Autowired
	ImsService service;
	
	@PostMapping("/addFaculty")
	public Integer addFaculty(@RequestBody Faculty faculty) {
		return service.addFaculty(faculty);
		
	}
	@PostMapping("/addStudent")
	public Integer addStudent(@RequestBody Student student) {
		System.out.println(student);
		return service.addStudent(student);
	}
	@GetMapping("/getCourses/{mobileNo}")
	private List<Course> getCourses(@PathVariable("mobileNo") Long mobileNo){
		return service.getCourses(mobileNo);
		
	}
	@GetMapping("/getAllFaculty/{courseName}")
	public List<Faculty> getAllFaculty(@PathVariable("courseName") String courseName){
		return service.getFaculty(courseName);
		
	}
	@PostMapping("/addCourses")
	public Integer addCourses(@RequestBody Course course) {
		System.out.println(course);
		return service.addCourses(course);
		
	}
	@GetMapping("/getAllCourses")
	public List<Course> getAllCourses(){
		return service.getAllCourses();
		
	}
	@GetMapping("/getStudents/{fmobile}")
	public List<Student> getStudents(@PathVariable("fmobile") Long fmobile){
		return service.getStudents(fmobile);
		
	}
	@GetMapping("/getAllStudents")
	public List<Student> getAllStudents(){
		return service.getAllStudents();
		
	}
	@GetMapping("/login/{mobileNo}/{password}")
	public Integer loginValidationFaculty(@PathVariable("mobileNo") Long mobileNo,@PathVariable("password") String password) {
		System.out.println(service.loginValidation(mobileNo,password));
		return service.loginValidation(mobileNo,password);
		
	}
	@GetMapping("/loginUser/{mobileNo}/{password}")
	public Integer loginValidationUser(@PathVariable("mobileNo") Long mobileNo,@PathVariable("password") String password) {
		return service.loginValidationUser(mobileNo,password);
		
	}
	@DeleteMapping("/deleteCourse/{courseName}")
	public Integer deleteCourse(@PathVariable("courseName") String courseName) {
		System.out.println(courseName);
		return service.deleteCourse(courseName);
		
	}
	@GetMapping("/getAllFaculty")
	public List<Faculty> getAllFaculty(){
		return service.getAllFaculty();
	}
	@DeleteMapping("/deleteFaculty/{fName}")
	public Integer deleteFaculty(@PathVariable("fName") String fName) {
		return service.deleteFaculty(fName);
		
	}
	@GetMapping("bookFaculty/{umobile}/{fmobile}/{courseName}")
	public Integer bookFaculty(@PathVariable("umobile") String umobile,@PathVariable("fmobile") String fmobile,@PathVariable("courseName") String courseName) {
		
		Long umail=Long.valueOf(umobile).longValue();
		Long fmail=Long.valueOf(fmobile).longValue();
		
		return service.bookFaculty(umail, fmail, courseName);
		
	}

}
