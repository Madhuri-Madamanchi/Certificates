package com.example.Ims.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.example.Ims.dto.Course;
import com.example.Ims.dto.Faculty;
import com.example.Ims.dto.Student;

@Repository
public class ImsDaoImp implements ImsDao {
	@Autowired
	MongoTemplate mongotemplate;
	
	@Override
	public Integer addFaculty(Faculty faculty) {
		System.out.println(faculty);
		mongotemplate.save(faculty);
		return 1;
	}

	@SuppressWarnings("unused")
	@Override
	public Integer addStudent(Student student) {
		Query query=new Query();
		query.addCriteria(Criteria.where("mobileNo").is(student.getMobileNo()));
		Student student1=mongotemplate.findOne(query, Student.class);
		if(student1==null)
		{
			mongotemplate.save(student);
			return 1;
		}
		
		return 2;
		
	}

	@Override
	public List<Course> getCourses(Long mobileNo) {
		Query query=new Query();
		query.addCriteria(Criteria.where("mobileNo").is(mobileNo));
		Student student=mongotemplate.findOne(query, Student.class);
		List<Course> course=student.getCourses();
		return course;
	}

	@Override
	public List<Faculty> getFaculty(String courseName) {
		// TODO Auto-generated method stub
		List<Faculty> faculty=mongotemplate.findAll(Faculty.class);
		List<Course> course=new ArrayList<>();
		List<Faculty> faculty2=new ArrayList<>();
		for(Faculty faculty1:faculty) {
			for(Course course1:faculty1.getCourses()) {
				if(course1.getCourseName().equalsIgnoreCase(courseName))
					faculty2.add(faculty1);
			}
		}
		
		return faculty2;
	}

	@Override
	public List<Faculty> getBookedFaculty(Long mobileNo) {
		Query query=new Query();
		query.addCriteria(Criteria.where("mobileNo").is(mobileNo));
		Student student=mongotemplate.findOne(query, Student.class);
		List<Faculty> faculty=student.getFaculty();
		return faculty;
	}

	@Override
	public Integer addCourses(Course course) {
		// TODO Auto-generated method stub
		List<Course> courses=mongotemplate.findAll(Course.class);
		 for(Course course1:courses) {
			 if(course1.getCourseName().equalsIgnoreCase(course.getCourseName()))
				 return 2;	 
		 }
		 mongotemplate.save(course);
		return 1;
		
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Course.class);
	}

	@Override
	public List<Student> getStudents(Long fmobile) {
		List<Student> students=mongotemplate.findAll(Student.class);
		List<Student> student1=new ArrayList<>();
		for(Student student:students) {
			System.out.println("faculty"+student.getFaculty());
			if(student.getFaculty()!=null)
			for(Faculty faculty:student.getFaculty()) {
				System.out.println(faculty.getName()+faculty.getMobileNo());
				if(faculty.getMobileNo().equals(fmobile))
					student1.add(student);
			}
		}
		
		return student1;
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Student.class);
	}

	@Override
	public Integer loginValidation(Long mobileNo, String password) {
		Query query=new Query();
		System.out.println(mobileNo);
		Long number=Long.parseLong("9876543210");
		if(mobileNo.equals(number) && password.equals("madhuri"))
			return 1;
		query.addCriteria(Criteria.where("mobileNo").is(mobileNo));
		Faculty faculty=mongotemplate.findOne(query, Faculty.class);
		if(faculty!=null && faculty.getPassword().equals(password))
			return 2;
		return 3;
		
	}

	@Override
	public Integer loginValidationUser(Long mobileNo, String password) {
		// TODO Auto-generated method stub
		System.out.println(mobileNo);
		Query query=new Query();
		query.addCriteria(Criteria.where("mobileNo").is(mobileNo));
		Student student=mongotemplate.findOne(query, Student.class);
		
		if(student!=null && student.getPassword().equals(password))
		return 1;
		else if(!(student!=null && student.getPassword().equals(password)))
			return 2;
		else
			return 3;
	}

	@Override
	public Integer deleteCourse(String courseName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("courseName").is(courseName));
		mongotemplate.remove(query, Course.class);
		return 1;
		
		
	}

	@Override
	public List<Faculty> getAllFaculty() {
		// TODO Auto-generated method stub
		List<Faculty> faculty=mongotemplate.findAll(Faculty.class);
		return faculty;
	}

	@Override
	public Integer deleteFaculty(String fName) {
		// TODO Auto-generated method stub
		Query query=new Query();
		query.addCriteria(Criteria.where("name").is(fName));
		mongotemplate.remove(query, Faculty.class);
		return 1;
	}

	@Override
	public Integer getBookedFaculty(Long umail, Long fmail, String courseName) {
		// TODO Auto-generated method stub
		Query query=new Query();
		query.addCriteria(Criteria.where("mobileNo").is(fmail));
		Faculty faculty=mongotemplate.findOne(query, Faculty.class);
		List<Course> courses=mongotemplate.findAll(Course.class);
		List<Course> course2=new ArrayList<>();
		List<Faculty> faculty1=new ArrayList<>();
		Course course1=new Course();
		for(Course course:courses) {
			if(course.getCourseName().equalsIgnoreCase(courseName))
				course1=course;			
		}
		List<Student> students=mongotemplate.findAll(Student.class);
		for(Student student:students) {
			if(student.getMobileNo().equals(umail)) {
				if(student.getCourses()!=null) {
					course2=student.getCourses();
					course2.add(course1);
					student.setCourses(course2);
					faculty1=student.getFaculty();
					faculty1.add(faculty);
					student.setFaculty(faculty1);
				}
				else
				{
					course2.add(course1);
					student.setCourses(course2);
					faculty1.add(faculty);
					student.setFaculty(faculty1);
				}
			}
			mongotemplate.save(student);
		}
		return 1;
	}

	
}
