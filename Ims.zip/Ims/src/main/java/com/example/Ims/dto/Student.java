package com.example.Ims.dto;
import java.util.List;

import org.springframework.data.annotation.Id;

public class Student {
	@Id
	private Long mobileNo;
	private String name,mailId,password;
	private List<Course> courses;
	private List<Faculty> faculty;
	public Long getMobileNo() {
		return mobileNo;
	}
	
	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	

	public List<Faculty> getFaculty() {
		return faculty;
	}

	public void setFaculty(List<Faculty> faculty) {
		this.faculty = faculty;
	}

	@Override
	public String toString() {
		return "Student [mobileNo=" + mobileNo + ", name=" + name + ", mailId=" + mailId + ", password=" + password
				+ ", courses=" + courses + ", faculty=" + faculty + "]";
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
	
